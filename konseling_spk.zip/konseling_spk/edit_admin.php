<?php 
$activerecord = new activerecord;
$proses = $activerecord->getWhere("pengguna","*","id_pengguna='$id_pengguna'");
$data=$activerecord->fetch($proses);
 ?>
<div class="row">
	<div class="col-lg-12">
        <h1 class="page-header">Edit Profil Admin</h1>
	</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row" >
    <div class="col-lg-6">

   	<form action="proses_edit_admin.php" method="POST" role="form">
   		
   	
   		<div class="form-group">
   			<label for="">Username</label>
   			<input type="text" name="username" class="form-control" value="<?php echo $data->username ?>" placeholder="contoh: Admin">
   		</div>
   		<div class="form-group">
   			<label for="">Nama Lengkap</label>
   			<input type="text" name="nama" class="form-control" value="<?php echo $data->nama_lengkap ?>" placeholder="contoh: Sari Susanti">
   		</div>
   		<div class="form-group">
   			<label for="">Password Lama</label>
   			<input type="password" name="lama" class="form-control"   placeholder="contoh: Password123">
   		</div>
   		<div class="form-group">
   			<label for="">Password Baru</label>
   			<input type="password" name="baru" class="form-control" id="" placeholder="contoh: Password12345">
   		</div>
   		<div class="form-group">
   			<label for="">Ulangi Password</label>
   			<input type="password" name="ulangi" class="form-control" id="" placeholder="contoh: Password12345">
   		</div>
   		<input type="hidden" name="id" value="<?php echo $id_pengguna ?>">
   	
   		
   	
   		<button type="submit" name="submit" class="btn btn-primary">Submit</button>
   	</form>
    </div>

</div>