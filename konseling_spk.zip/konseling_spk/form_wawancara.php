<?php 

$totalsoal = $_SESSION['totalsoal'];
$id_pengguna = $_SESSION['id_pengguna'];
$activerecord = new activerecord;

$proses = $activerecord->getWhere("tb_nilai","*","id_pengguna = '$id_pengguna'");

$ketemu = $proses->num_rows;

if ($ketemu >0) {
	echo "Ujian telah selesai. Silahkan lihat nilai anda disini <a href='index.php?menu=hasil'>Click disini</a>";
}
else
{


 ?>
<div class="container">
	<div class="row">
		<div class=" col-md-12">
			<div class="panel panel-default">
				  <div class="panel-heading">
				  <?php if ($totalsoal<=10) {
				  		echo "<h3 class=\"panel-title\">Soal $totalsoal dari 10</h3>";
				  }
				  else
				  {
				  	echo "<h3 class=\"panel-title\">Selesai</h3>";
				  	} ?>
						
				  </div>
				  <div class="panel-body">
				  	<form action="prosesujian.php" method="POST" accept-charset="utf-8">
						<?php 
							if (isset($_GET['status'])) {
								echo "ujian telah selesai<br>";
								$nilai = $_SESSION['nilai'];
								echo "Nilai anda : ".$nilai;
								$id_pengguna=$_SESSION['id_pengguna'];
									if (isset($_SESSION['nilai'])) {
										//include_once 'library/activerecord.php';
										date_default_timezone_set("Asia/Jakarta");
										$tahun = date("Y");
										$activerecord = new activerecord;
										$cari = $activerecord->getWhere("tb_nilai","*","id_pengguna='$id_pengguna'");
										$ketemu = $cari->num_rows;
										
										if ($ketemu>0) {
												if ($data=$cari->fetch_object()) {
													$total =( $data->nilai_administrasi + $data->nilai_wawancara + $nilai)/3;
												}
											$proses = $activerecord->getUpdate("tb_nilai","nilai_ujian = '$nilai', total_hasil='$total'","id_pengguna='$id_pengguna'");
										}
										else
										{	
											$total = (0+0+$nilai)/3;
											$proses = $activerecord->getInsert("tb_nilai","'','$id_pengguna','','','$nilai','$total','$tahun'");
										}
									}
									unset($_SESSION['nilai']);
									unset($_SESSION['totalsoal']);

								}
							else {
								if ($totalsoal<=10) {
								//include_once 'library/activerecord.php';
								$activerecord = new activerecord;
								$proses = $activerecord->getOrderby("tb_soal","rand()","desc");
								if ($soal = $proses->fetch_object()) {
										echo $soal->soal."<br><br>";
										$id_soal = $soal->id_soal;
										$query = $activerecord->getOrder("tb_pilihan","*","id_soal='$id_soal'","rand()","desc");
										foreach ($query as $key => $pilihan) {
											?>
											
												<input type="hidden" name="id_soal" value="<?php echo $id_soal ?>">
												<input type="radio" name="pilihan" value="<?php echo $pilihan['id_pilihan'] ?>" placeholder="<?php echo $pilihan['jawaban'] ?>"> <?php echo $pilihan['jawaban'] ?><br>
												
											
											<?php
										}
										
										echo "<br><button class=\"btn btn-primary\" type=\"submit\">Next</button>";
									}
								}
								else
								{
									echo "<script>document.location='index.php?menu=ujian&status=success';</script>";
								}
							}
						 ?>
						 	
						 </form>
				  </div>
			</div>
		</div>
	</div>
</div>
<?php } ?>

