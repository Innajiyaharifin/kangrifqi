<?php 
if (isset($_POST['submit'])) {
	include_once 'library/activerecord.php';
	$nilaiw=$_POST['nilaiw'];
	$nilaia=$_POST['nilaia'];
	$id_pengguna = $_POST['id'];
	
	$activerecord = new activerecord;
	$proses = $activerecord->getWhere("tb_nilai","*","id_pengguna='$id_pengguna'");
	$ketemu = $activerecord->numRows($proses);
	if ($ketemu>0) {
		$proses = $activerecord->getUpdate("tb_nilai","nilai_administrasi='$nilaia', nilai_wawancara='$nilaiw'","id_pengguna='$id_pengguna'");
	}
	else
	{
		$proses = $activerecord->getInsert("tb_nilai","'','$id','$nilaiw','$nilaia',''");
	}
	if ($proses) {
		$prosestampil = $activerecord->getWhere("tb_nilai","*","id_pengguna='$id_pengguna'");
		if($data = $activerecord->fetch($prosestampil))
		{
			$total = ($data->nilai_administrasi + $data->nilai_wawancara + $data->nilai_ujian)/3;
			$proses = $activerecord->getUpdate("tb_nilai","total_hasil='$total'","id_pengguna='$id_pengguna'");
			if ($proses) {
				header("location: index.php?menu=data_pendaftar");
				//echo($total);
			}
			else
			{
				echo "Gagal".$activerecord->error();
			}
		}
	}
	else
	{
		echo "Gagal";
	}

	
	

	
}
 ?>