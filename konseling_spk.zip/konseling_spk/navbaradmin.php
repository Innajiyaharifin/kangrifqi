        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="padding:10px 10px 10px 10px;"href="#" ><img src="images/bsis.jpg" width="32px" height="32px"></a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav hidden-xs">
                <li><a href="">Sistem Informasi Manajemen Konseling dan SPK</a></li>
            </ul>
            
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div style="position: fixed;" class="navbar-default sidebar affix-top" role="navigation">
                <div class="sidebar-nav navbar-collapse ">
                    <ul class="nav" id="side-menu">
                        <li>
                            <h4 style="margin: 15px">Menu Guru</h4>
                        </li>
                         <li>
                            <a href="index.php?menu=profil_admin"><i class="fa fa-user fa-fw"></i>Profil Guru</a>
                        </li>
                        <li>
                            <a href="index.php?menu=data_pendaftar"><i class="fa fa-users fa-fw"></i>Data Siswa</a>
                        </li>
                      
                        <li>
                            <a href="index.php?menu=seleksi"><i class="fa fa-check-square-o fa-fw"></i>Monitoring Siswa</a>
                        </li>
                        <li>
                            <a href="index.php?menu=laporanditerima"><i class="fa fa-bar-chart fa-fw"></i>Hasil SPK</a>
                        </li>
                        <li>
                            <a href="index.php?menu=buatsoal"><i class="fa fa-edit fa-fw"></i>Tambah Pertanyaan</a>
                        </li>
                        <li>
                            <a href="index.php?menu=tambahadmin"><i class="fa fa-gears fa-fw"></i>Pengaturan</a>
                        </li>
                        <li>
                            <a href="keluar.php"><i class="fa fa-sign-out fa-fw"></i>Keluar</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>