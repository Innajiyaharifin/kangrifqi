<?php 
session_start();
$id_pengguna = $_SESSION['id_pengguna'];
$username = $_POST['username'];
$nama = $_POST['nama'];
$lama = $_POST['lama'];
$baru = md5($_POST['baru']);
$ulangi = md5($_POST['ulangi']);

if ($baru != $ulangi) {
	$_SESSION['flash']['info'] = "warning";
	$_SESSION['flash']['message'] = "Password Baru anda tidak sama dengan ulangi password";
	header("location: index.php?menu=edit_admin");

}
else
{
	include 'library/activerecord.php';
	$activerecord = new activerecord;
	$proses = $activerecord->getWhere("pengguna","*","id_pengguna='$id_pengguna'");
	if($data= $activerecord->fetch($proses))
	{
		if ($data->password!= md5($lama)) {
			$_SESSION['flash']['info'] = "warning";
			$_SESSION['flash']['message'] = "Password Lama anda tidak sama dengan yang ada di database";
			header("location: index.php?menu=edit_admin");
		}
		else
		{
			$update = $activerecord->getUpdate("pengguna","username='$username',password='$baru',nama_lengkap='$nama'","id_pengguna='$id_pengguna'");
			if ($update) {
				$_SESSION['flash']['info'] = "success";
				$_SESSION['flash']['message'] = "Berhasil!!... Profil anda sudah berubah";
				header("location: index.php?menu=edit_admin");
			}
		}
	}
}


 ?>