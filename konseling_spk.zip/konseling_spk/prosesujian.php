<?php 
session_start();
if (isset($_POST['pilihan'])) {
	$id_pengguna = $_SESSION['id_pengguna'];
	$pilihan=$_POST['pilihan'];
	$id_soal=$_POST['id_soal'];
	$_SESSION['totalsoal']++;

	include_once 'library/activerecord.php';
	$activerecord = new activerecord;
	$proses = $activerecord->getInsert("tb_jawaban","'','$id_pengguna','$pilihan', '$id_soal'");

	$carijawaban = $activerecord->getWhere("tb_pilihan","*","id_pilihan='$pilihan'");
	if ($data=$carijawaban->fetch_object()) {
		if ($data->keterangan==1) {
			$_SESSION['nilai']+=10;
		}
	}
	header("location: index.php?menu=ujian");
}
 ?>