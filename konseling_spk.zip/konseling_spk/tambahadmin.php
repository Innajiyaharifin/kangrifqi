<div class="row">
	<div class="col-lg-12">
        <h1 class="page-header">Tambah Admin</h1>
	</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<form action="prosesdaftaradmin.php" method="POST" role="form">
						   	<legend align="center">Form Pendaftaran Admin</legend>
						   
						   	<div class="form-group">
						   		<label for="">Nama Lengkap</label>
						   		<input name="nama_lengkap" type="text" class="form-control" id="" placeholder="Masukan Nama Lengkap">
						   	</div>

						   	<div class="form-group">
						   		<label for="">Nama Pengguna</label>
						   		<input name="username"type="text" class="form-control" id="" placeholder="Masukan Nama pengguna ">
						   	</div>

						   <div class="form-group">
						   		<label for="">Kata Sandi</label>
						   		<input type="password" name="password"class="form-control" id="" placeholder="Masukan Kata Sandi">
						   	</div>

						   <div class="form-group">
						   <label>Pertanyaan Keamanan</label>
						   <select name="pertanyaan" id="inputPertanyaan" class="form-control" required="required">
						   		<option value="1"> Sebutkan Nama hewan peliharaan Anda?</option>
						   		<option value="2"> Sebutkan Nama Artis favorit Anda?</option>
						   		<option value="3"> Sebutkan Nama Paman Anda?</option>
						   		<option value="4"> Sebutkan Nama Panggilan Anda?</option>
						   </select>
						   </div>
						   <div class="form-group">
						   		<label for="">Jawaban Keamanan</label>
						   		<input name="jawaban"type="text" class="form-control" id="" placeholder="Masukan Jawaban">
						   	</div>
						   
						   
						   	
						   
						   	<button name="simpan" type="submit" class="btn btn-primary">Submit</button>
						   </form>
	</div>
</div>