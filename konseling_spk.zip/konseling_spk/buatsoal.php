<div class="row">
<div class="col-lg-12">
        <h1 class="page-header">Home   <a href="index.php?menu=semuasoal" class="btn btn-default">Bank Soal</a></h1> 
</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row" >
    <div class="col-lg-6">
    <div class="panel panel-default">
    	<div class="panel-body">
    	   <form action="prosesbuatsoal.php" method="POST" role="form">
    	   	<legend>Buat Soal</legend>
    	   
    	   	<div class="row">
    	   		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    	   			<div class="form-group">
		    	   		<label for="">Pertanyaan</label>
		    	   		<textarea name="pertanyaan" id="inputPertanyaan" class="form-control" rows="3" required="required"></textarea>
    	   			</div>
    	   		</div>
    	   	</div>
    	   	<div class="row">
    	   		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    	   			<div class="form-group">
		    	   		<input type="text" name="benar" style="border: 1px solid #04F522;" id="inputBenar" class="form-control" required="required"  placeholder="Jawaban Benar">
    	   			</div>
    	   		</div>
    	   		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    	   			<div class="form-group">
		    	   		
		    	   		<input type="text" name="salah1" style="border: 1px solid #FB0A0A;" id="inputBenar" class="form-control" required="required"  placeholder="Jawaban Salah">
    	   			</div>
    	   		</div>
    	   		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    	   			<div class="form-group">
		    	   		
		    	   		<input type="text" name="salah2" style="border: 1px solid #FB0A0A;" id="inputBenar" class="form-control" required="required"  placeholder="Jawaban Salah">
    	   			</div>
    	   		</div>
    	   		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    	   			<div class="form-group">
		    	   		
		    	   		<input type="text" name="salah3" style="border: 1px solid #FB0A0A;" id="inputBenar" class="form-control" required="required"  placeholder="Jawaban Salah">
    	   			</div>
    	   		</div>
    	   	</div>

    	   
    	   	
    	   
    	   	<button type="submit"  name="submit" class="btn btn-primary">Submit</button>
    	   </form>
    	</div>
    </div>
   
    </div>

</div>
