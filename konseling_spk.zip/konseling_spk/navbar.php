        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- logo <img src="images/bsis.jpg" width="32px" height="32px"></a>
            </div>-->
            <!-- /.navbar-header -->
             <center><ul class="nav navbar-nav hidden-xs ">
               <li><a href="">Sistem Informasi Manajemen Konseling dan SPK</a></li>
            </ul></center>
            
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div style="position: fixed;" class="navbar-default sidebar affix-top" role="navigation">
                <div class="sidebar-nav navbar-collapse ">
                    <ul class="nav" id="side-menu">
                        <li>
                            <h4 style="margin: 15px">Menu Siswa</h4>
                        </li>
                         <li>
                            <a href="?menu=biodata"><i class="fa fa-home fa-fw"></i>Biodata Diri</a>
                        </li>
                        <li>
                            <a href="index.php?menu=ujian"><i class="fa fa-edit fa-fw"></i>Monitoring</a>
                        </li>
                        <li>
                            <a href="index.php?menu=ujian"><i class="fa fa-edit fa-fw"></i>SPK Jurusan</a>
                        </li>
                        <li>
                            <a href="?menu=hasil"><i class="fa fa-file-archive-o fa-fw"></i>Hasil Ujian</a>
                        </li>
                        <li>
                            <a href="keluar.php"><i class="fa fa-sign-out fa-fw"></i>Keluar</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>