<?php 

    session_start();
    //$id_pendaftar=$_SESSION['id_pendaftar'];
    include_once 'library/activerecord.php';
$i=1;
        $table = "tb_soal as a";
        $field = "*";
        $where = "a.id_soal";
        $order = "a.soal";
        $sort = "asc";
        $activerecord = new activerecord;
        $proses = $activerecord->getOrder($table, $field,$where, $order, $sort);

        

    $jsonResult = '{"data" : [ {';
    $i=1;
    $arr = array();
    while ($row=$proses->fetch_assoc()) {
      $id_soal=$row['id_soal'];
      $ppilihan = $activerecord->getWhere("tb_pilihan","*","id_soal='$id_soal'");
      $a=1;
      foreach ($ppilihan as $key => $pilihan) {
        if ($pilihan['keterangan'] == 1) {
          $benar = $pilihan['jawaban'];
        }
        else
        {
          $salah[$a] = $pilihan['jawaban'];
          $a++;
        }
        
      }
      $link = "<a href='index.php?menu=edit_soal&id=$row[id_soal]' class='btn btn-danger'>Edit Soal</a>
      <a href='index.php?menu=hapus_soal&id=$row[id_soal]' class='btn btn-primary'>Hapus Soal</a>
      ";

       $temp = array(
      "No" => $i,
        "Soal" => $row['soal'],
        "Jawaban Benar" => $benar,
        "Jawaban Salah 1" => $salah[1],
        "Jawaban Salah 2" => $salah[2], 
        "Jawaban Salah 3" => $salah[3], 
        "Lihat Detail" => $link);

       array_push($arr, $temp);
       $i++;
    }
    $data = json_encode($arr);
 
echo "{\"data\":" . $data . "}";


?>