<?php 
include_once 'library/activerecord.php';

if (isset($_POST['simpan'])) 
{
	
	$nama_lengkap=$_POST['nama_lengkap'];
	$username=$_POST['username'];
	$password=md5($_POST['password']);
	$pertanyaan=$_POST['pertanyaan'];
	$jawaban=md5($_POST['jawaban']);

	$table = "pengguna"; //table yang digunakan
	$value = "'', '$nama_lengkap', '$username', '$password', '$pertanyaan', '$jawaban','0'"; //field yang ditampilkan
	
try {
	$activerecord = new activerecord;
	$proses = $activerecord->getInsert($table,$value); //nama table, nama field, where nya
	if ($proses) 
	{
		header("location: index.php");
	}
	else
	{
		echo "<script> alert('Data gagal disimpan'); document.location='index.php'</script>";
	}
} catch (Exception $e) {
	echo "<script>alert('Data Sudah ada'); document.location='index.php'</script>";
}
	

}


 ?>