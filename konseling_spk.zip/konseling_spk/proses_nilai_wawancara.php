<?php 
include_once 'library/activerecord.php';
$opsi1=$_POST['opsi1'];
$opsi2=$_POST['opsi2'];
$opsi3=$_POST['opsi3'];
$opsi4=$_POST['opsi4'];
$opsi5=$_POST['opsi5'];
$opsi6=$_POST['opsi6'];
$opsi7=$_POST['opsi7'];
$opsi8=$_POST['opsi8'];
$opsi9=$_POST['opsi9'];
$opsi10=$_POST['opsi10'];
$opsi11=$_POST['opsi11'];
$opsi12=$_POST['opsi12'];
$opsi13=$_POST['opsi13'];
$opsi14=$_POST['opsi14'];
$opsi15=$_POST['opsi15'];
$opsi16=$_POST['opsi16'];
$opsi17=$_POST['opsi17'];
$opsi18=$_POST['opsi18'];
$opsi19=$_POST['opsi19'];
$opsi20=$_POST['opsi20'];
$opsi21=$_POST['opsi21'];
$opsi22=$_POST['opsi22'];
$opsi23=$_POST['opsi23'];
$opsi24=$_POST['opsi24'];
$opsi25=$_POST['opsi25'];
$opsi26=$_POST['opsi26'];
$opsi27=$_POST['opsi27'];
$opsi28=$_POST['opsi28'];
$opsi29=$_POST['opsi29'];
$opsi30=$_POST['opsi30'];
$nilai_wawancara=$opsi1+$opsi2+$opsi3+$opsi4+$opsi5+$opsi6+$opsi7+$opsi8+$opsi9+$opsi10+$opsi11+$opsi12+$opsi13+$opsi14+$opsi15+$opsi16+$opsi17+$opsi18+$opsi19+$opsi20+$opsi21+$opsi22+$opsi23+$opsi24+$opsi25+$opsi26+$opsi27+$opsi28+$opsi29+$opsi30;
$id_pengguna = $_POST['id'];


	$activerecord = new activerecord;
	$proses = $activerecord->getWhere("tb_nilai","*","id_pengguna='$id_pengguna'");
	$ketemu = $activerecord->numRows($proses);
	if ($ketemu>0) {
		$proses = $activerecord->getUpdate("tb_nilai","nilai_wawancara='$nilai_wawancara'","id_pengguna='$id_pengguna'");
	}
	else
	{
		$proses = $activerecord->getInsert("tb_nilai","'','$id','$nilai_wawancara'");
	}
	if ($proses) {
		$prosestampil = $activerecord->getWhere("tb_nilai","*","id_pengguna='$id_pengguna'");
		if($data = $activerecord->fetch($prosestampil))
		{
			$total = ($data->nilai_administrasi + $data->nilai_wawancara + $data->nilai_ujian)/3;
			$proses = $activerecord->getUpdate("tb_nilai","total_hasil='$total'","id_pengguna='$id_pengguna'");
			if ($proses) {
				header("location: index.php?menu=data_pendaftar");
				//echo($total);
			}
			else
			{
				echo "Gagal".$activerecord->error();
			}
		}
	}
	else
	{
		echo "Gagal";
	}


 ?>