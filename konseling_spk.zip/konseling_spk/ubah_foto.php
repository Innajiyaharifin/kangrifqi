<div class="row">
	<div class="col-lg-12">
        <h1 class="page-header">Ubah Foto Profil</h1>
	</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row" >
    <div class="col-lg-12">

<form action="proses_ubah_foto.php" method="post" enctype="multipart/form-data" accept-charset="utf-8">
	<input type="file" name="gambar" value="" placeholder="">
	<br>
	<input type="submit" name="submit">
</form>
</div>
</div>