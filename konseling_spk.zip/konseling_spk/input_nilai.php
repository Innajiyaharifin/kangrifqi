<?php 
$id= $_GET['id'];
$activerecord = new activerecord;
$proses = $activerecord->getWhere("pengguna as a, tb_nilai as b","*","b.id_pengguna='$id' and a.id_pengguna = b.id_pengguna");
if ($data=$proses->fetch_object()) {
  $nw = $data->nilai_wawancara;
  $na = $data->nilai_administrasi;

}
else
{
  $nw ="";
  $na = "";
}
 ?>

<div class="row">
	<div class="col-lg-12">
        <h1 class="page-header">Input Nilai</h1>
	</div>
</div>
    <!-- /.col-lg-12 -->
<div class="row" >
    <div class="col-lg-12">

   	<form action="proses_inputnilai.php" method="POST" role="form">
   		<legend>Form title</legend>
   	
   		<!--<div class="form-group">
   			<label for="">Nilai Wawancara</label>
   			<input type="text" name="nilaiw" value="<?php echo $nw ?>" class="form-control" id="" placeholder="0-100">
   		</div>-->
   		<div class="form-group">
   			<label for="">Nilai Administrasi</label>
   			<input type="text" name="nilaia" value="<?php echo $na ?>" class="form-control" id="" placeholder="0-100">
   		</div>
   		<input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
   	
   		
   	
   		<button type="submit" name="submit" class="btn btn-primary">Submit</button>
   	</form>
    </div>

</div>
