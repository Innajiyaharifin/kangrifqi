 <footer style="    padding-left: 35%;
    padding-top: 15px;">
 &copy; <?php echo date('Y'); ?> <strong>Sistem Informasi Manajemen Konseling dan SPK</strong>. All rights reserved. <a href="http://smkmvp.sch.id">Rifqi</a>
  </footer>