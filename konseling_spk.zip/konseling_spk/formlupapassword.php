<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Tit</title>

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<div class="panel panel-default" style="margin-top:50px">
						<div class="panel-body">
						   <form action="prosesformpasswordlama.php" method="POST" role="form">
								<legend align="center">Form Lupa Kata sandi</legend>
							
								<div class="form-group">
									<label for="">Username</label>
									<input name="username" type="text" class="form-control" id="" placeholder="Masukan Username">
								</div>
								<div class="form-group">
								   <label>Pertanyaan Keamanan</label>
								   <select name="pertanyaan" id="inputPertanyaan" class="form-control" required="required">
								   		<option value="1"> Sebutkan Nama hewan peliharaan Anda?</option>
								   		<option value="2"> Sebutkan Nama Artis favorit Anda?</option>
								   		<option value="3"> Sebutkan Nama Paman Anda?</option>
								   		<option value="4"> Sebutkan Nama Panggilan Anda?</option>
								   </select>
								</div>
							   <div class="form-group">
							   		<label for="">Jawaban Keamanan</label>
							   		<input name="jawaban"type="text" class="form-control" id="" placeholder="Masukan Jawaban">
							   	</div>
							   	<div class="form-group">
							   		<label for="">Password Baru</label>
							   		<input name="passwordbaru" type="password" class="form-control" id="" placeholder="Masukan password baru" >
							   	</div>

							
								
							
								<button name="simpan"type="submit" class="btn btn-primary">Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- jQuery -->
		<script src="js/jquery.min.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>