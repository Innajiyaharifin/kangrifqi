<?php 
$activerecord= new activerecord;
$id=$_GET['id'];
$proses = $activerecord->getDelete("tb_soal","id_soal='$id'");
if ($proses) {
				$_SESSION['flash']['info'] = "success";
				$_SESSION['flash']['message'] = "Berhasil!!... ";
				echo "<script>document.location='index.php?menu=semuasoal';</script>";
				//header("location: ");
}
else
{
		$_SESSION['flash']['info'] = "danger";
				$_SESSION['flash']['message'] = "Gagal!!... ";
				echo "<script>document.location='index.php?menu=semuasoal';</script>";
}

 ?>