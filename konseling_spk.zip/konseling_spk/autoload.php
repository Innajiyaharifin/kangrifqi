<?php 
spl_autoload_register(function ($class)
{
	include 'library/'.$class.'.php';
});

 ?>