<?php 
if (isset($_POST['simpan'])){
	$username = $_POST['username'];
	$pertanyaan = $_POST['pertanyaan'];
	$jawaban = md5($_POST['jawaban']);
	$passwordbaru = md5($_POST['passwordbaru']);

	include('library/activerecord.php');
	$activerecord = new activerecord;
	$proses = $activerecord->getWhere("pengguna","*","username='$username' AND pertanyaan_keamanan='$pertanyaan' AND jawaban_keamanan='$jawaban'");
	$ketemu = $proses->num_rows;
	if ($ketemu>0) {
		$proses = $activerecord->getupdate("pengguna","password='$passwordbaru'","username='$username'");
		if ($proses) {
			echo "<script> alert('Berhasil.. berhasil.. berhasil. horeee'); document.location='login.php';</script>";
		}
		else{
			echo "<script> alert('Data gagal disimpan'); document.location='formlupapassword.php';</script>";
		}
	}
	else{
		echo "<script> alert('Data Tidak cocok') ;document.location='formlupapassword.php'; </script>";
	}
}

 ?>