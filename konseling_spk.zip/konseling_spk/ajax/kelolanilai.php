<?php 
if( isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) && ( $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest' ) )
{
    session_start();
    $kelas=$_SESSION['id_kelasjurusan'];
    include_once '../../koneksi.php';

    $query = $mysqli->query("SELECT siswa.nis, siswa.nama_siswa from siswa, kelasjurusan, kelas where siswa.id_kelasjurusan=kelasjurusan.id_kelasjurusan and kelas.kode_kelas=kelasjurusan.kode_kelas and siswa.id_kelasjurusan='$kelas' order by siswa.nama_siswa asc");
    $jsonResult = '{"data" : [ {';
    $i=1;
    $arr = array();
    while ($row=$query->fetch_assoc()) {
      $link = "<a href='main_walikelas.php?url_walikelas=tampilnilai&nis=$row[nis]' class='btn btn-primary'>Kelola Nilai</a>";

       $temp = array(
      "No" => $i,
        "NIS" => $row['nis'],
        "Nama" => $row["nama_siswa"],  
        "Proses Nilai" => $link);

       array_push($arr, $temp);
       $i++;
    }
    $data = json_encode($arr);
 
echo "{\"data\":" . $data . "}";
} else {
    echo '<script>window.location="../../404.html"</script>';
}

?>