<?php 

    session_start();
    //$id_pendaftar=$_SESSION['id_pendaftar'];
    include_once 'library/activerecord.php';
        $kuota = $_GET['kuota'];
        $grade = $_GET['grade'];

        $table = "tb_nilai,pengguna";
        $field = "*";
        $where = "pengguna.id_pengguna=tb_nilai.id_pengguna and tb_nilai.total_hasil >= $grade";
        $order = "pengguna.nama_lengkap";
        $sort = "asc limit $kuota";
        $activerecord = new activerecord;
        $proses = $activerecord->getOrder($table, $field,$where, $order, $sort);
        

    $jsonResult = '{"data" : [ {';
    $i=1;
    $arr = array();
    while ($row=$proses->fetch_assoc()) {
      $link = "<a href='index.php?menu=hapus_seleksi&id=$row[id_pengguna]' class='btn btn-primary'>Hapus</a>";

       $temp = array(
      "No" => $i,
        "namalengkap" => $row['nama_lengkap'],
        "username" => $row["username"],
        "nilaiw" => $row["nilai_wawancara"],
        "nilaia" => $row["nilai_administrasi"],
        "nilaiu" => $row["nilai_ujian"],
        "total" => $row["total_hasil"]);

       array_push($arr, $temp);
       $i++;
    }
    $data = json_encode($arr);
 
echo "{\"data\":" . $data . "}";


?>