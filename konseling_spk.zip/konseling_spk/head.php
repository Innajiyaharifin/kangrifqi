<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" contesnt="">
    <meta name="author" content="">

    <title>SPK</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/metisMenu.min.css" rel="stylesheet">

    <!-- datatabel -->
    <link rel="stylesheet" href="css/dataTables.bootstrap.css">

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="css/tableraport.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="images/mvp.png">
    <link rel="stylesheet" type="text/css" href="js/morris/morris.css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .custombg{
                    background-color : #FFFEF9;
                }
        .bgcol{
                    background-color: #F5F5F5;
        }
        .bghome{
                    background-color: #fc4225;
        }
    </style>

</head>