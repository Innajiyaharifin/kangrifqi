<?php 
$id_pengguna=$_SESSION['id_pengguna'];
$activerecord = new activerecord;
$proses = $activerecord->getWhere("tb_nilai,pengguna","*","pengguna.id_pengguna = '$id_pengguna' and pengguna.id_pengguna = tb_nilai.id_pengguna");
$data = $activerecord->fetch($proses);
 ?>
<div class="container">

	<div class="row">
		<div class="col-lg-12">
	        <h1 class="page-header">Hasil Ujian</h1>
	</div>
	</div>
	    <!-- /.col-lg-12 -->
	<div class="row" >
	    <div class="col-lg-6">

	    	<table class="table table-hover">
	    			<tr class="success">
	    				<th>Nama</th>
	    				<td><?php echo $data->nama_lengkap; ?></td>
	    			</tr>
	    		
	    			<tr>
	    				<th>Nilai Wawancara</th>
	    				<td><?php echo $data->nilai_wawancara; ?></td>
	    			</tr>
	    		
	    			<tr>
	    				<th>Nilai Administrasi</th>
	    				<td><?php echo $data->nilai_administrasi; ?></td>
	    			</tr>
	    			<tr>
	    				<th>Nilai Ujian</th>
	    				<td><?php echo $data->nilai_ujian; ?></td>
	    			</tr>
	    			<tr>
	    				<th>Total</th>
	    				<td><?php echo $data->total_hasil; ?></td>
	    			</tr>
	    		
	    	</table>		
	   
	    </div>

	</div>
	
</div>
