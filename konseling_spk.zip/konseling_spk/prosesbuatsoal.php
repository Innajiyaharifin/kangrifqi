<?php
require 'library/activerecord.php';
session_start();
$pertanyaan = $_POST['pertanyaan'];
$benar = $_POST['benar'];
$salah1=$_POST['salah1'];
$salah2=$_POST['salah2'];
$salah3=$_POST['salah3'];

$id_pengguna = $_SESSION['id_pengguna'];


$activerecord = new activerecord;
$proses = $activerecord->getInsert("tb_soal","'','$pertanyaan','$id_pengguna'");
if ($proses) {
	$query = $activerecord->getOrderby("tb_soal","id_soal","desc limit 1");
	$data = $activerecord->fetch($query);
	$benar = $activerecord->getInsert("tb_pilihan","'','$data->id_soal','$benar','1'");
	$salah1 = $activerecord->getInsert("tb_pilihan","'','$data->id_soal','$salah1','0'");
	$salah2 = $activerecord->getInsert("tb_pilihan","'','$data->id_soal','$salah2','0'");
	$salah3 = $activerecord->getInsert("tb_pilihan","'','$data->id_soal','$salah3','0'");
	if ($benar and $salah1 and $salah2 and $salah3) {
	
		$_SESSION['flash']['message'] = "Berhasil. Soal berhasil dibuat";
		$_SESSION['flash']['info']= "success";
		header("location: index.php?menu=buatsoal");
	}
}	
else
{
	echo "error";
}