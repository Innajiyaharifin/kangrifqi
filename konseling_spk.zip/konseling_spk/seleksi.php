	<?php $activerecord = new activerecord;
        $proses = $activerecord->getAll("tb_kuota");
        $data = $activerecord->fetch($proses); ?>
    <div class="col-lg-12">
    	<h1 class="page-header">Seleksi</h1>
	</div>
    <div class="row">
        <div class="  col-md-2 ">
            <form action="proses_seleksi.php" method="POST" role="form">           
                <div class="form-group">
                    <label for="">Kuota</label>
                    <input name="kuota" type="text" value="<?php echo $data->kuota; ?>" class="form-control" id="" maxlength="3" placeholder="0-999">
                </div>
        </div>
        <div class="  col-md-3 col-sm-12 ">
                <div class="form-group">
                    <label for="">Passing Grade</label>
                    <input name="grade" type="text" class="form-control" value="<?php echo $data->passing_grade ?>" id="" maxlength="3" placeholder="0-100">

                </div>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
            <button type="submit" class="btn btn-primary" style="
    margin-top: 25px;">Update</button>

        </div>

        
    </form>
    </div>

	<div class="row">
		<div class="col-md-12">

			 <div class="table-responsive">

                <table class="table table-striped table-bordered table-hover" id="seleksi">
                    <thead>
                        <tr>
                        	<th>No </th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Nilai Wawancara </th>
                            <th>Nilai Administrasi</th>
                            <th>Nilai Ujian</th>
                            <th>Nilai Total</th>
                        </tr>
                    </thead>
                </table>
            </div>
		</div>
		
	</div>
	
