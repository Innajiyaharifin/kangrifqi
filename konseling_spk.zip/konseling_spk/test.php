<?php 
$mysql_server = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_db = "db_testing";
$mysqli = new mysqli($mysql_server, $mysql_user, $mysql_password, $mysql_db);
if ($mysqli->connect_errno) {
	printf("Connection failed: %s \n", $mysqli->connect_error);
	exit();
}
$mysqli->set_charset("utf8");

for ($i=0; $i < 700 ; $i++) { 
	date_default_timezone_set("Asia/Jakarta");
				$tahun = date('ym');
				 $noform=str_pad($i, 3,"0", STR_PAD_LEFT);
					$kode="TR".$tahun.$noform;
	$proses = $mysqli->query("INSERT INTO tb_natural values ('$kode')");
}
		

 ?>